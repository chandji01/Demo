
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Bmi extends JFrame {

    JLabel jlb, age, gender, height, cm, weight, kg;
    JTextField txtage, txtheight, txtweight;
    JRadioButton male, female;
    JButton calculate, clear;

    Bmi() {

        jlb = new JLabel("BMI CALCULTOR");
        jlb.setBounds(200, 10, 300, 30);
        jlb.setForeground(Color.BLUE);
        jlb.setFont(new Font("Raileway", Font.BOLD, 28));
        add(jlb);

        age = new JLabel("AGE");
        age.setBounds(50, 80, 150, 30);
        age.setFont(new Font("Railway", Font.BOLD, 20));
        add(age);

        txtage = new JTextField();
        txtage.setBounds(200, 80, 250, 30);
        txtage.setFont(new Font("Railway", Font.BOLD, 15));
        add(txtage);

        gender = new JLabel("GENDER");
        gender.setBounds(50, 140, 150, 30);
        gender.setFont(new Font("Railway", Font.BOLD, 20));
        add(gender);

        male = new JRadioButton("MALE");
        male.setBounds(200, 140, 100, 30);
        male.setBackground(Color.white);
        male.setFont(new Font("Railway", Font.BOLD, 15));
        add(male);

        female = new JRadioButton("FEMALE");
        female.setBounds(300, 140, 100, 30);
        female.setFont(new Font("Railway", Font.BOLD, 15));
        female.setBackground(Color.white);
        add(female);

        ButtonGroup genderg = new ButtonGroup();
        genderg.add(male);
        genderg.add(female);

        height = new JLabel("HEIGHT");
        height.setBounds(50, 200, 150, 30);
        height.setFont(new Font("Railway", Font.BOLD, 20));
        add(height);

        txtheight = new JTextField();
        txtheight.setBounds(200, 200, 250, 30);
        txtheight.setFont(new Font("Railway", Font.BOLD, 15));
        add(txtheight);

        cm = new JLabel("CM");
        cm.setBounds(450, 200, 50, 30);
        cm.setFont(new Font("Railway", Font.BOLD, 18));
        add(cm);

        weight = new JLabel("WEIGHT");
        weight.setBounds(50, 260, 150, 30);
        weight.setFont(new Font("Railway", Font.BOLD, 20));
        add(weight);

        txtweight = new JTextField();
        txtweight.setBounds(200, 260, 250, 30);
        txtweight.setFont(new Font("Railway", Font.BOLD, 15));
        add(txtweight);

        kg = new JLabel("KG");
        kg.setBounds(450, 260, 50, 30);
        kg.setFont(new Font("Railway", Font.BOLD, 18));
        add(kg);

        ActionListener al = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                if (txtage.getText().isEmpty() || txtheight.getText().isEmpty() || txtweight.getText().isEmpty()
                        || (!male.isSelected() && !female.isSelected())) {
                    JOptionPane.showMessageDialog(null, "Please fill in all the fields.", "Error", JOptionPane.ERROR_MESSAGE);

                } else {

                    Double weight = Double.parseDouble(txtweight.getText());
                    Double height = Double.parseDouble(txtheight.getText());
                    Double h = height / 100;
                    Double bmi = weight / (h * h);
                    Double ibw = height - 100;
                    String q = String.format("%.2f", bmi);
                    String w = String.format("%.2f", ibw);
                    String e = null;
                    if (bmi <= 16) {
                        e = "Severe Thinness";
                    } else if (bmi > 16 && bmi <= 17) {
                        e = "Moderate Thinness";
                    } else if (bmi > 17 && bmi <= 18.5) {
                        e = "Mild Thinness";
                    } else if (bmi > 18.5 && bmi <= 25) {
                        e = "Healthy";
                    } else if (bmi > 25 && bmi <= 30) {
                        e = "Overweight";
                    } else if (bmi > 30 && bmi <= 35) {
                        e = "Obese Class I";
                    } else if (bmi > 35 && bmi <= 40) {
                        e = "Obese Class II";
                    } else if (bmi > 40) {
                        e = "Obese Class III";
                    }
                    new Result(q, w, e);
                }
            }
        };

        calculate = new JButton("CALCULATE");
        calculate.setBounds(150, 350, 150, 30);
        calculate.addActionListener(al);
        add(calculate);

        ActionListener ab = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                txtage.setText("");
                txtheight.setText("");
                txtweight.setText("");
                male.setSelected(false);
                female.setSelected(false);
            }
        };

        clear = new JButton("CLEAR");
        clear.setBounds(330, 350, 100, 30);
        clear.addActionListener(ab);
        add(clear);

        setSize(600, 500);
        setLocation(400, 100);
        setTitle("BODY MASS INDEX");
        setDefaultCloseOperation(3);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setVisible(true);

    }
    public static void main(String[] args) throws Exception {
        new Bmi();
    }
}

class Result extends JFrame {

    JLabel res, ibw, bmires, ibwres, rang, scale;

     Result(String a, String b, String c) {
        res = new JLabel("BMI(BODY MASS INDEX)");
        res.setBounds(120, 10, 400, 30);
        res.setFont(new Font("Raleway", Font.BOLD, 20));
        add(res);

        bmires = new JLabel(a);
        bmires.setBounds(200, 50, 400, 30);
        bmires.setForeground(Color.green);
        bmires.setFont(new Font("Raleway", Font.BOLD, 20));
        add(bmires);

        scale = new JLabel(c);
        scale.setBounds(180, 80, 400, 30);
        scale.setFont(new Font("Raleway", Font.BOLD, 20));
        add(scale);

        ibw = new JLabel(" : IBW(IDEAL BODY WEIGHT)FOR THIS HEIGHT");
        ibw.setBounds(20, 160, 550, 30);
        ibw.setFont(new Font("Raleway", Font.BOLD, 20));
        add(ibw);

        ibwres = new JLabel(b);
        ibwres.setBounds(200, 200, 400, 30);
        ibwres.setFont(new Font("Raleway", Font.BOLD, 20));
        add(ibwres);

        rang = new JLabel(" : Healthy BMI range: 18.5 kg/m2 - 25 kg/m2");
        rang.setBounds(20, 250, 550, 30);
        rang.setFont(new Font("Raleway", Font.BOLD, 20));
        add(rang);

        setSize(500, 400);
        setLayout(null);
        setTitle("RESULT");
        setDefaultCloseOperation(3);
        getContentPane().setBackground(Color.white);
        setLocation(450, 140);
        setVisible(true);

    }
}
